import { VersionedTransaction, Connection, Keypair, sendAndConfirmTransaction } from '@solana/web3.js';
import bs58 from "bs58";
import fetch from 'node-fetch'; // da usare se non hai fetch globale

async function sendLocalCreateBundle(){
    const signerKeyPairs = [
        Keypair.fromSecretKey(bs58.decode("3aHUYqnByKaRqfg1oSbDvDeq2TkbkJLcLRUHXiuQtJKpCAFnHpb96HF65arfCQyMW7p341PMrJJ6a3LHS65HejJN")),
        Keypair.fromSecretKey(bs58.decode("5ErRDAWNmUHnhk2mqZgxj2nDBSqB2rafeaUPDrLQKHEH3S3i46gzmun9SQR8y7TuDNAj6h5tkCrLWgHZCFwTY4V1")),
        // use up to 5 wallets
    ];
    
   
    const bundledTxArgs = [
        {
            "publicKey": signerKeyPairs[0].publicKey.toBase58(),
            "action": "buy", 
            "mint": "4tYqyHkQqHuw9WfNGcWuwEg8SeLj3i9k85BxLSJepump", 
            "denominatedInSol": "true",  
            "amount": 0.02, 
            "slippage": 10, 
            "priorityFee": 0.00005, // priority fee after first tx is ignored
            "pool": "pump"
        },
        {
            publicKey: signerKeyPairs[1].publicKey.toBase58(),
            "action": "buy", 
            "mint": "4tYqyHkQqHuw9WfNGcWuwEg8SeLj3i9k85BxLSJepump", 
            "denominatedInSol": "true",  
            "amount": 0.02, 
            "slippage": 10, 
            "priorityFee": 0.00005, // priority fee after first tx is ignored
            "pool": "pump"
        },
        // use up to 5 transactions
        
    ];
    const response = await fetch(`https://pumpportal.fun/api/trade-local`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(bundledTxArgs)
    });
    if(response.status === 200){ // successfully generated transactions
        const transactions = await response.json();
        let encodedSignedTransactions = [];
        let signatures = [];
        for(let i = 0; i < bundledTxArgs.length; i++){
            const tx = VersionedTransaction.deserialize(new Uint8Array(bs58.decode(transactions[i])));
            if(bundledTxArgs[i].action === "create"){  // creation transaction needs to be signed by mint and creator keypairs
                tx.sign([mintKeypair, signerKeyPairs[i]])
            } else {
                tx.sign([signerKeyPairs[i]]);
            }
            encodedSignedTransactions.push(bs58.encode(tx.serialize()));
            signatures.push(bs58.encode(tx.signatures[0]));
        }
        
        try{
            const jitoResponse = await fetch(`https://mainnet.block-engine.jito.wtf/api/v1/bundles`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "sendBundle",
                    "params": [
                    encodedSignedTransactions
                    ]
                })
            });
            console.log(jitoResponse);
        } catch(e){
            console.error(e.message);
        }
        for(let i = 0; i < signatures.length; i++){
            console.log(`Transaction ${i}: https://solscan.io/tx/${signatures[i]}`);
        }
    } else {
        console.log(response.statusText); // log error
    }
}

sendLocalCreateBundle();