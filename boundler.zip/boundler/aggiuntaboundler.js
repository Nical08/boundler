import {
    VersionedTransaction,
    Connection,
    Keypair,
    Transaction,
    SystemProgram,
    sendAndConfirmTransaction,
    clusterApiUrl
  } from '@solana/web3.js';
  import bs58 from "bs58";
  import fetch from 'node-fetch';
  import FormData from 'form-data';
  import { writeFile } from 'fs/promises';
  import { readFile } from 'fs/promises';
  
  const LAMPORTS_PER_SOL = 1e9;
  
  // Funzione per generare un wallet e salvarlo in un file univoco
  async function generateAndSaveWallet(alias) {
    const wallet = Keypair.generate();
    const publicKey = wallet.publicKey.toBase58();
    const secretKeyBase58 = bs58.encode(wallet.secretKey);
    const fileName = `${alias}_${Date.now()}.json`;
    const walletData = { publicKey, secretKey: secretKeyBase58 };
    await writeFile(fileName, JSON.stringify(walletData, null, 2), 'utf8');
    console.log(`Wallet ${alias} generato e salvato in ${fileName}`);
    return wallet;
  }
  
  // Funzione per splittare i fondi dal testWallet ai wallet destinatari
  async function splitFunds(testWallet, recipients, connection) {
    // Ottieni il saldo del test wallet (in lamports)
    const testBalance = await connection.getBalance(testWallet.publicKey);
    console.log("Saldo test wallet:", testBalance);
  
    // Calcola l'importo da inviare ad ogni wallet (escludendo una eventuale fee minima)
    const splitAmount = Math.floor(testBalance / recipients.length);
    console.log("Importo da inviare a ciascun wallet:", splitAmount);
  
    // Per ciascun wallet, crea e invia una transazione di trasferimento
    for (const recipient of recipients) {
      const tx = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: testWallet.publicKey,
          toPubkey: recipient.publicKey,
          lamports: splitAmount,
        })
      );
      // Invia e conferma la transazione
      await sendAndConfirmTransaction(connection, tx, [testWallet]);
      console.log(`Inviato ${splitAmount} lamports a ${recipient.publicKey.toBase58()}`);
    }
  }
  
  // Funzione principale che esegue tutta la logica
  async function sendLocalCreateBundle() {
    // Crea la connessione (ad esempio, su Devnet per i test)
    const connection = new Connection(clusterApiUrl('devnet'));
  
    // 1. Genera il test wallet e gli altri wallet (che andranno a firmare le transazioni)
    const testWallet = await generateAndSaveWallet("test");
    const signerKeyPairs = [
      await generateAndSaveWallet("wallet1"),
      await generateAndSaveWallet("wallet2"),
      // Aggiungi altri wallet se necessario (fino a 5)
    ];
  
    // 2. Split dei fondi: il testWallet invia fondi in egual misura a ciascun wallet
    await splitFunds(testWallet, signerKeyPairs, connection);
  
    // (Opzionale) Attendi qualche secondo per essere sicuro che i trasferimenti siano confermati
    await new Promise(resolve => setTimeout(resolve, 10000));
  
    // 3. Preparazione del token: genera il mint keypair e carica i metadati (immagine, ecc.)
    const mintKeypair = Keypair.generate();
  
    // Carica l'immagine da file (qui si usa readFile per ottenere un Buffer)
    const fileBuffer = await readFile("./new-moon-face.png");
  
    let tokenMetadata = {
      name: "TEST",
      symbol: "AAA",
      description: "This is an example token created via PumpPortal.fun",
      twitter: "https://x.com/a1lon9/status/1812970586420994083",
      telegram: "https://x.com/a1lon9/status/1812970586420994083",
      website: "https://pumpportal.fun",
      file: fileBuffer,
    };
  
    let formData = new FormData();
    formData.append("file", tokenMetadata.file, { filename: "new-moon-face.png" });
    formData.append("name", tokenMetadata.name);
    formData.append("symbol", tokenMetadata.symbol);
    formData.append("description", tokenMetadata.description);
    formData.append("twitter", tokenMetadata.twitter || "");
    formData.append("telegram", tokenMetadata.telegram || "");
    formData.append("website", tokenMetadata.website || "");
    formData.append("showName", "true");
  
    // Invio dei metadati a PumpPortal per ottenere l'URI (su IPFS)
    let metadataResponse = await fetch("https://pump.fun/api/ipfs", {
      method: "POST",
      body: formData,
    });
    let metadataResponseJSON = await metadataResponse.json();
  
    // 4. Preparazione delle transazioni per ciascun wallet
    // La prima transazione sarà di tipo "create" e le successive di tipo "buy".
    const bundledTxArgs = [];
    for (let i = 0; i < signerKeyPairs.length; i++) {
      const wallet = signerKeyPairs[i];
      // Ottieni il saldo corrente del wallet (in lamports)
      const balance = await connection.getBalance(wallet.publicKey);
      // Calcola l'importo da utilizzare: saldo - 0.02 SOL (0.02 * LAMPORTS_PER_SOL)
      const feeLamports = Math.floor(0.02 * LAMPORTS_PER_SOL);
      const amountLamports = balance > feeLamports ? balance - feeLamports : 0;
  
      if (i === 0) {
        bundledTxArgs.push({
          publicKey: wallet.publicKey.toBase58(),
          action: "create",
          tokenMetadata: {
            name: tokenMetadata.name,
            symbol: tokenMetadata.symbol,
            uri: metadataResponseJSON.metadataUri,
          },
          mint: mintKeypair.publicKey.toBase58(),
          denominatedInSol: "false",
          amount: amountLamports, // Usa l'ammontare disponibile meno 0.02 SOL
          slippage: 10,
          priorityFee: 0.0001, // Fee usata per il Jito tip (solo per il primo tx)
          pool: "pump",
        });
      } else {
        bundledTxArgs.push({
          publicKey: wallet.publicKey.toBase58(),
          action: "buy",
          mint: mintKeypair.publicKey.toBase58(),
          denominatedInSol: "false",
          amount: amountLamports,
          slippage: 10,
          priorityFee: 0.00005, // Fee ignorata per le tx successive
          pool: "pump",
        });
      }
    }
  
    console.log("Bundled Transaction Arguments:", bundledTxArgs);
  
    // 5. Ottieni le transazioni pre-bundled dal server PumpPortal
    const response = await fetch("https://pumpportal.fun/api/trade-local", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(bundledTxArgs)
    });
  
    if(response.status === 200) {
      const transactions = await response.json();
      let encodedSignedTransactions = [];
      let signatures = [];
      for(let i = 0; i < bundledTxArgs.length; i++){
        const tx = VersionedTransaction.deserialize(new Uint8Array(bs58.decode(transactions[i])));
        // Per l'azione "create" (primo wallet) firmare con mintKeypair e wallet; per "buy" solo con il wallet
        if(bundledTxArgs[i].action === "create"){
          tx.sign([mintKeypair, signerKeyPairs[i]]);
        } else {
          tx.sign([signerKeyPairs[i]]);
        }
        encodedSignedTransactions.push(bs58.encode(tx.serialize()));
        signatures.push(bs58.encode(tx.signatures[0]));
      }
      
      // 6. Invia il bundle a Jito
      try {
        const jitoResponse = await fetch("https://mainnet.block-engine.jito.wtf/api/v1/bundles", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            jsonrpc: "2.0",
            id: 1,
            method: "sendBundle",
            params: [ encodedSignedTransactions ]
          })
        });
        console.log("Risposta Jito:", jitoResponse.status);
      } catch(e) {
        console.error(e.message);
      }
      
      // Stampa gli URL di Solscan per monitorare le transazioni
      for(let i = 0; i < signatures.length; i++){
        console.log(`Transaction ${i}: https://solscan.io/tx/${signatures[i]}`);
      }
    } else {
      console.log("Errore:", response.statusText);
    }
  }
  
  sendLocalCreateBundle();
  